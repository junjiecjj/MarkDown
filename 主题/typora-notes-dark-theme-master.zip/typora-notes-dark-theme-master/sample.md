# Notes Dark theme for Typora

Regular, *italic*, **bold**, ==highlighted==, `monospace` and <kbd>kbd</kbd>

```javascript
const [count, setCount] = useState(0);
```

It has [colored links]()

## Stripped tables

| Option     | Description                                                |
| ---------- | ---------------------------------------------------------- |
| The option | The description of that option you wrote on the other cell |

> This is a quote, also useful for document notes

### Tasks

- [x] Something done
- [ ] Something to do [^1]

[^1]: Here is the footnote.
