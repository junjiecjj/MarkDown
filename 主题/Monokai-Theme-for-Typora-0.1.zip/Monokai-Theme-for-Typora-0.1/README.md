# Monokai Theme

This is my theme inspired from the Monokai (created by [Wimer Hazenberg](https://github.com/monokai)). It is supposed to be finished. However, if you see something incorrect, or hideous, you can still make your own changes.

##	Installation

Download this repository anywhere on your computer.

```shell
git clone https://github.com/valfur03/Monokai-Theme-for-Typora
```

Open Typora and go into the preference panel. Select `Appearance` and click on `Open Theme Folder`.

Move the `light-monokai.css` file into the Typora's Themes Folder.

Restart Typora, and select your newly downloaded Theme from the menu bar.

##	Contribution

If you wish to, you are free to contribute on this repository. Just follow [this guide](https://github.com/firstcontributions/first-contributions).

