# Engwrite

This is an [english-stackexchange-like](http://english.stackexchange.com/) theme, especially suitable for writing in english.

## Preview

![1](https://i.imgur.com/eRSZ5LZ.png)
