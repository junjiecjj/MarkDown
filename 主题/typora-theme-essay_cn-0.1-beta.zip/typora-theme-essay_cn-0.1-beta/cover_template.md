<div class="cover" style="page-break-after:always;font-family:仿宋;width:100%;height:100%;border:none;margin: 0 auto;text-align:center;">
    <div style="width:80%;;margin: 0 auto;height:0;padding-bottom:25%;">
        <img src="校名.svg" alt="校名" style="width:100%;"/>
    </div>
    </br></br></br></br>
    <div style="width:40%;margin: 0 auto;height:0;padding-bottom:40%;">
        <img src="校标.svg" alt="校徽" style="width:100%;"/>
	</div>
    </br></br>
    <p style="text-align:center;font-size:24pt;margin: 0 auto">《课程名称》</p>
    <p style="text-align:center;font-size:24pt;margin: 0 auto">论文类型 </p>
    </br>
    </br>
    <table style="border:none;text-align:center;width:80%;font-family:仿宋;margin: 0 auto;">
    <tbody style="font-family:仿宋;font-size:16pt;">
    	<tr style="font-weight:bold;"> 
    		<td style="width:30%;text-align:justify;">题    目</td>
    		<td style="width:5%">：</td> 
    		<td style="font-weight:normal;border-bottom: 2px solid;text-align:center;"> 论文题目</td>     </tr>
    	<tr style="font-weight:bold;"> 
    		<td style="width:30%;text-align:justify;">上课时间</td>
    		<td style="width:5%">：</td> 
    		<td style="font-weight:normal;border-bottom: 2px solid;text-align:center;"> 上课时间</td>     </tr>
    	<tr style="font-weight:bold;"> 
    		<td style="width:30%;text-align:justify;">授课教师</td>
    		<td style="width:5%">：</td> 
    		<td style="font-weight:normal;border-bottom: 2px solid;text-align:center;">教师姓名 </td>     </tr>
    	<tr style="font-weight:bold;"> 
    		<td style="width:30%;text-align:justify;">姓    名</td>
    		<td style="width:5%">：</td> 
    		<td style="font-weight:normal;border-bottom: 2px solid;text-align:center;"> 你的名字</td>     </tr>
    	<tr style="font-weight:bold;"> 
    		<td style="width:30%;text-align:justify;">学    号</td>
    		<td style="width:5%">：</td> 
    		<td style="font-weight:normal;border-bottom: 2px solid;text-align:center;">你的学号 </td>     </tr>
    	<tr style="font-weight:bold;"> 
    		<td style="width:30%;text-align:justify;">组    别</td>
    		<td style="width:5%">：</td> 
    		<td style="font-weight:normal;border-bottom: 2px solid;text-align:center;"> 你的组别</td>     </tr>
    	<tr style="font-weight:bold;"> 
    		<td style="width:30%;text-align:justify;">日    期</td>
    		<td style="width:5%">：</td> 
    		<td style="font-weight:normal;border-bottom: 2px solid;text-align:center;">完成日期 </td>     </tr>
    </tbody>              
    </table>
</div>


