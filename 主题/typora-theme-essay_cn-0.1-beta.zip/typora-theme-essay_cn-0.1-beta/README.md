# typora-theme-essay_cn
一个简单的、为中文课程论文排版设计的Typora主题。 | A theme for Typora(a markdown editor), designed for chinese essay.

[详细介绍 | Detailed Introduction(chinese)]()

## 安装 | Installation

[可参见Typora官方文档 | see Typora docs](http://support.typora.io/About-Themes/)

太长不看 | short version:

0. [点此 | click here]()下载主题文件 | download theme
 
1. 打开Typora偏好设置 |  File-Preference。（<kbd>Ctrl</kbd> +<kbd>,</kbd>）
 
2. 外观-主题-打开主题文件夹  | Appearance-Themes-Open Theme Folder
 
3. 将下载的essay.css文件放入此文件夹 |  move the downloaded file essay.css here
 
4. 重启Typora，选取essay主题 | restart Typora, and select theme "essay"

## 预览 | Preview

![效果图]()
